//
//  LDCSDAServiceTypesModel.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/11/21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LDCSDAServiceTypesModel : NSObject
// decimal    否    服务价格
@property (nonatomic,assign) float price;
// int 否 服务类型编码：1.Video Reading 2.Voice Call 3.Video Call
@property (nonatomic,assign) NSInteger service_code;
// string    否    服务名称：1.Video Reading 2.Voice Call 3.Video Call
@property (nonatomic,strong) NSString *service_name;
// int    否    服务类型状态：0：不可用，1：可用
@property (nonatomic,assign) NSInteger state;

@end

NS_ASSUME_NONNULL_END
