//
//  LDCSDAConstant.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/24.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

// notification
extern NSString *const CO_DA_VISITOR_LOGIN_SUCCESS_NOTIFICATION;
extern NSString *const CO_DA_UPDATE_BALANCE_NOTIFICATION;
extern NSString *const CO_DA_UPDATE_ORDER_NOTIFICATION;
extern NSString *const CO_DA_CHANGE_ORDER_NOTIFICATION;
extern NSString *const CO_DA_ADVISOR_ORDER_CHANGE_NOTIFICATION;
extern NSString *const CO_DA_UPDATE_ALL_ORDER_NOTIFICATION;
extern NSString *const CO_DA_HAS_NO_READ_ORDER_NOTIFICATION;
extern NSString *const CO_DA_ORDER_SHOW_NOTIFICATION;
extern NSString *const CO_DA_SCROLL_TO_TEACHRR_TYPE_NOTIFICATION;


// 业务id
extern NSString *const CO_DA_DIVINATION_ADVISER_FUN_ID;

NS_ASSUME_NONNULL_END
